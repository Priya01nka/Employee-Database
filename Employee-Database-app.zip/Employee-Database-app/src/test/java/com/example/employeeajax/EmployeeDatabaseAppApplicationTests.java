package com.example.employeeajax;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class EmployeeDatabaseAppApplicationTests {

	@Test
	void contextLoads() {
	}

}
