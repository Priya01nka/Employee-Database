const API = "/api/employees";
fetch(API, {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify(emp),
})


const els = {
  form: document.getElementById("emp-form"),
  id: document.getElementById("emp-id"),
  name: document.getElementById("emp-name"),
  email: document.getElementById("emp-email"),
  dept: document.getElementById("emp-dept"),
  msg: document.getElementById("msg"),
  tableBody: document.querySelector("#emp-table tbody"),
  formTitle: document.getElementById("form-title"),
  cancelBtn: document.getElementById("cancel-btn"),
  search: document.getElementById("search"),
};

async function api(path = "", options = {}) {
  const res = await fetch(`${API}${path}`, {
    headers: { "Content-Type": "application/json" },
    ...options
  });
  if (!res.ok) {
    const text = await res.text();
    throw new Error(text || `HTTP ${res.status}`);
  }
  // 204 No Content -> return null
  return res.status === 204 ? null : res.json();
}

function rowHTML(e) {
  return `
    <tr data-id="${e.id}">
      <td>${e.id}</td>
      <td>${e.name}</td>
      <td>${e.email}</td>
      <td>${e.department ?? ""}</td>
      <td class="action-links">
        <a data-action="edit">Edit</a>
        <a data-action="delete">Delete</a>
      </td>
    </tr>`;
}

let ALL = []; // cache for search/filter

async function load() {
  try {
    const data = await api("");
    ALL = data;
    render(ALL);
  } catch (e) {
    flash(`Load failed: ${e.message}`, true);
  }
}

function render(list) {
  els.tableBody.innerHTML = list.map(rowHTML).join("");
}

function flash(message, isError = false) {
  els.msg.style.color = isError ? "#c00" : "#0b7";
  els.msg.textContent = message;
  setTimeout(() => (els.msg.textContent = ""), 2500);
}

function resetForm() {
  els.id.value = "";
  els.name.value = "";
  els.email.value = "";
  els.dept.value = "";
  els.formTitle.textContent = "Add Employee";
  els.cancelBtn.classList.add("hidden");
}

els.form.addEventListener("submit", async (ev) => {
  ev.preventDefault();
  const payload = {
    name: els.name.value.trim(),
    email: els.email.value.trim(),
    department: els.dept.value.trim()
  };
  try {
    if (els.id.value) {
      // update
      const id = els.id.value;
      const updated = await api(`/${id}`, {
        method: "PUT",
        body: JSON.stringify(payload)
      });
      // update cache & DOM
      ALL = ALL.map(e => e.id == id ? updated : e);
      render(filter(els.search.value));
      flash("Employee updated");
      resetForm();
    } else {
      // create
      const created = await api("", { method: "POST", body: JSON.stringify(payload) });
      ALL.push(created);
      render(filter(els.search.value));
      flash("Employee added");
      resetForm();
    }
  } catch (e) {
    flash(e.message, true);
  }
});

document.addEventListener("click", async (ev) => {
  const el = ev.target;
  if (!(el.tagName === "A" && el.dataset.action)) return;

  const tr = el.closest("tr");
  const id = tr?.dataset.id;
  const item = ALL.find(e => e.id == id);

  if (el.dataset.action === "edit") {
    els.id.value = item.id;
    els.name.value = item.name;
    els.email.value = item.email;
    els.dept.value = item.department ?? "";
    els.formTitle.textContent = "Edit Employee";
    els.cancelBtn.classList.remove("hidden");
  }

  if (el.dataset.action === "delete") {
    if (!confirm(`Delete #${id} ${item.name}?`)) return;
    try {
      await api(`/${id}`, { method: "DELETE" });
      ALL = ALL.filter(e => e.id != id);
      render(filter(els.search.value));
      flash("Employee deleted");
    } catch (e) {
      flash(e.message, true);
    }
  }
});

els.cancelBtn.addEventListener("click", resetForm);

function filter(q) {
  q = (q || "").toLowerCase();
  if (!q) return ALL.slice();
  return ALL.filter(e =>
    (e.name || "").toLowerCase().includes(q) ||
    (e.email || "").toLowerCase().includes(q) ||
    (e.department || "").toLowerCase().includes(q)
  );
}

els.search.addEventListener("input", (e) => {
  render(filter(e.target.value));
});

load();
