package com.example.employeeajax.service;

import com.example.employeeajax.model.Employee;
import com.example.employeeajax.repository.EmployeeRepository;
import org.springframework.stereotype.Service;
import java.util.List;

@Service
public class EmployeeService {
  private final EmployeeRepository repo;

  public EmployeeService(EmployeeRepository repo) { this.repo = repo; }

  public List<Employee> all() { return repo.findAll(); }
  public Employee one(int id) { return repo.findById(id); }
  public Employee create(Employee e) { return repo.create(e); }
  public boolean update(Employee e) { return repo.update(e) > 0; }
  public boolean delete(int id) { return repo.delete(id) > 0; }
}
