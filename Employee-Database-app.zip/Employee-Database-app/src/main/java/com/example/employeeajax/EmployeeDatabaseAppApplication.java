package com.example.employeeajax;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class EmployeeDatabaseAppApplication {
  public static void main(String[] args) {
    SpringApplication.run(EmployeeDatabaseAppApplication.class, args);
  }
}
