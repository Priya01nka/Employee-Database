package com.example.employeeajax.controller;

import com.example.employeeajax.model.Employee;
import com.example.employeeajax.service.EmployeeService;
import jakarta.validation.Valid;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import java.net.URI;
import java.util.List;

@RestController
@RequestMapping("/api/employees")
public class EmployeeRestController {
  private final EmployeeService service;

  public EmployeeRestController(EmployeeService service) { this.service = service; }

  @GetMapping
  public List<Employee> list() {
    return service.all();
  }

  @GetMapping("/{id}")
  public ResponseEntity<Employee> get(@PathVariable int id) {
    try { return ResponseEntity.ok(service.one(id)); }
    catch (Exception e) { return ResponseEntity.notFound().build(); }
  }

  @PostMapping
  public ResponseEntity<Employee> create(@Valid @RequestBody Employee e) {
    Employee saved = service.create(e);
    return ResponseEntity.created(URI.create("/api/employees/" + saved.getId())).body(saved);
  }

  @PutMapping("/{id}")
  public ResponseEntity<Employee> update(@PathVariable int id, @Valid @RequestBody Employee e) {
    e.setId(id);
    return service.update(e) ? ResponseEntity.ok(e) : ResponseEntity.notFound().build();
  }

  @DeleteMapping("/{id}")
  public ResponseEntity<Void> delete(@PathVariable int id) {
    return service.delete(id) ? ResponseEntity.noContent().build() : ResponseEntity.notFound().build();
  }
}
