package com.example.employeeajax.repository;

import com.example.employeeajax.model.Employee;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.support.GeneratedKeyHolder;
import org.springframework.jdbc.support.KeyHolder;
import org.springframework.stereotype.Repository;
import java.sql.PreparedStatement;
import java.util.List;

@Repository
public class EmployeeRepository {

  private final JdbcTemplate jdbc;

  public EmployeeRepository(JdbcTemplate jdbc) {
    this.jdbc = jdbc;
  }

  private static final org.springframework.jdbc.core.RowMapper<Employee> MAPPER = (rs, n) -> {
    Employee e = new Employee();
    e.setId(rs.getInt("id"));
    e.setName(rs.getString("name"));
    e.setEmail(rs.getString("email"));
    e.setDepartment(rs.getString("department"));
    return e;
  };

  public List<Employee> findAll() {
    return jdbc.query("SELECT id, name, email, department FROM employees ORDER BY id", MAPPER);
  }

  public Employee findById(int id) {
    return jdbc.queryForObject(
      "SELECT id, name, email, department FROM employees WHERE id = ?",
      MAPPER, id);
  }

  public Employee create(Employee e) {
    String sql = "INSERT INTO employees(name, email, department) VALUES (?,?,?)";
    KeyHolder kh = new GeneratedKeyHolder();
    jdbc.update(con -> {
      PreparedStatement ps = con.prepareStatement(sql, new String[]{"id"});
      ps.setString(1, e.getName());
      ps.setString(2, e.getEmail());
      ps.setString(3, e.getDepartment());
      return ps;
    }, kh);
    Number key = kh.getKey();
    e.setId(key == null ? null : key.intValue());
    return e;
  }

  public int update(Employee e) {
    return jdbc.update(
      "UPDATE employees SET name = ?, email = ?, department = ? WHERE id = ?",
      e.getName(), e.getEmail(), e.getDepartment(), e.getId());
  }

  public int delete(int id) {
    return jdbc.update("DELETE FROM employees WHERE id = ?", id);
  }
}
